# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
RITSurv::Application.config.secret_token = '04728acb3d9d4bfd7542c6b517fdbacb8061086a0e820e0e9f1fa725f022b32740b01aed8467e881d3f5416f3627f1e8ae3aa0cce227ae6d5a03af398fa9fa23'
